Thank you for purchasing kunefe for pterodactyl 1.x

To install the theme upload the files in the Kunefe Folder, 

Then run the following commands

yarn install
yarn add react-gravatar
yarn add @types/react-gravatar
yarn add @fortawesome/free-brands-svg-icons
php artisan migrate --force
yarn build:production
php artisan cache:clear
php artisan view:clear

If there are any issues or you need help please open a ticket in my discord
https://discord.com/invite/HYweeZw3zR